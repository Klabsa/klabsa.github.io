---
layout: post
title:  "Ingenieros en Soluciones Industriales / Análisis y Administración de Riesgos"
author: 
categories: [ Jekyll, tutorial ]
image: assets/images/5.jpg
---

Soluciones Industriales
